chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "scan_links") {
        scanPage(request.token);
    }
});

async function scanPage(token) {
    console.log("CTI Scanner: Received scan command. Searching for email content...");

    const selectors = ['.a3s.aiL', '.ii.gt', '.WordSection1', 'div[aria-label="Message body"]'];
    let emailBody = null;
    for (const selector of selectors) {
        emailBody = document.querySelector(selector);
        if (emailBody) break;
    }
    
    if (!emailBody) {
        alert("CTI Scanner Error: Could not automatically find the email content on this page.");
        chrome.runtime.sendMessage({ status: 'error', message: 'Could not find email body.' });
        return;
    }

    // --- NEW: Extract the text content of the email ---
    const emailText = emailBody.innerText;

    // Find all links within the same email body
    const linkElements = emailBody.querySelectorAll('a[href]');
    const urlsToScan = Array.from(linkElements).map(link => link.href);

    // Remove old icons before starting a new scan
    document.querySelectorAll('.cti-scan-icon').forEach(icon => icon.remove());
    
    // --- NEW: Create the combined payload ---
    const payload = {
        email_text: emailText,
        urls: urlsToScan
    };

    try {
        // --- NEW: Call the new, combined API endpoint ---
        const response = await fetch('http://127.0.0.1:5000/ext/analyze_email_content', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}` 
            },
            body: JSON.stringify(payload) // Send the combined payload
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || `Server error: ${response.status}`);
        }

        const data = await response.json();
        let maliciousUrlCount = 0;

        // --- NEW: Show an alert with the email verdict ---
        if (data.email_verdict && data.email_verdict !== 'Not Scanned') {
            alert(`CTI Email Scan Result: This email is classified as "${data.email_verdict}".`);
        }
        
        // Process the URL results and place icons (this part is the same)
        if (data.url_results) {
            linkElements.forEach(link => {
                const result = data.url_results.find(r => r.url === link.href);
                if (result) {
                    const icon = document.createElement('span');
                    icon.className = 'cti-scan-icon';
                    icon.style.marginLeft = '5px';
                    if (result.verdict === 'Malicious') {
                        icon.textContent = '🚨';
                        icon.title = `MALICIOUS! Score: ${result.risk_score}%`;
                        maliciousUrlCount++;
                    } else {
                        icon.textContent = '✅';
                        icon.title = 'Safe.';
                    }
                    link.parentNode.insertBefore(icon, link.nextSibling);
                }
            });
        }
        
        // Send a more detailed "complete" message back to the popup
        chrome.runtime.sendMessage({ 
            status: 'complete', 
            email_verdict: data.email_verdict,
            malicious_url_count: maliciousUrlCount 
        });

    } catch (error) {
        alert(`CTI Scanner Error: ${error.message}`);
        chrome.runtime.sendMessage({ status: 'error', message: error.message });
    }
}