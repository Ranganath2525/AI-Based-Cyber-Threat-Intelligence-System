// Get all the UI elements
const loginView = document.getElementById('login-view');
const mainView = document.getElementById('main-view');
const status = document.getElementById('status');
const loginBtn = document.getElementById('loginBtn');
const scanBtn = document.getElementById('scanBtn');
const logoutBtn = document.getElementById('logoutBtn');
const loggedInUser = document.getElementById('loggedInUser');

// --- THIS IS THE ROBUST STORAGE API ---
// It checks for 'browser' (standard) first, then falls back to 'chrome'.
const storage = (typeof browser !== "undefined") ? browser.storage : chrome.storage;

// --- STATE MANAGEMENT ---

function showLoginView() {
    loginView.classList.remove('hidden');
    mainView.classList.add('hidden');
    status.textContent = 'Please login with your dashboard credentials.';
}

function showMainView(username) {
    loginView.classList.add('hidden');
    mainView.classList.remove('hidden');
    loggedInUser.textContent = username;
    status.textContent = '';
}

// --- EVENT HANDLERS ---

loginBtn.addEventListener('click', async () => {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
    if (!username || !password) {
        status.textContent = "Username and password are required.";
        return;
    }
    status.textContent = "Logging in...";

    try {
        const response = await fetch('http://127.0.0.1:5000/ext/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error);

        // Login successful, save token and username using the robust API
        storage.sync.set({ jwtToken: data.token, username: username }, () => {
            if (chrome.runtime.lastError) {
                console.error("Error saving to storage:", chrome.runtime.lastError);
                status.textContent = "Error: Could not save login session.";
                return;
            }
            showMainView(username);
        });

    } catch (error) {
        status.textContent = `Login failed: ${error.message}`;
    }
});

logoutBtn.addEventListener('click', () => {
    // Clear saved data
    storage.sync.remove(['jwtToken', 'username'], () => {
        showLoginView();
    });
});

scanBtn.addEventListener('click', () => {
    status.textContent = 'Scanning...';
    // Get the saved token
    storage.sync.get(['jwtToken'], (result) => {
        if (!result.jwtToken) {
            status.textContent = "Authentication error. Please login again.";
            showLoginView();
            return;
        }

        // Get the active tab and inject the content scanner
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                files: ['content_scanner.js']
            }).then(() => {
                // After injecting, send the token to the content scanner
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: "scan_links",
                    token: result.jwtToken
                });
            });
        });
    });
});


// --- THIS IS THE UPGRADED PART ---
// Listen for the new, more detailed "complete" message
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.status === 'complete') {
        // Display a more informative summary
        status.textContent = `Email: ${request.email_verdict} | URLs: ${request.malicious_url_count} threats found.`;
    } else if (request.status === 'error') {
        status.textContent = `Error: ${request.message}`;
    }
});

// --- INITIALIZATION ---

// When the popup opens, check if we are already logged in
document.addEventListener('DOMContentLoaded', () => {
    storage.sync.get(['jwtToken', 'username'], (result) => {
        if (result.jwtToken && result.username) {
            showMainView(result.username);
        } else {
            showLoginView();
        }
    });
});